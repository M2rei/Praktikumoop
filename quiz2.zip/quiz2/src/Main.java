public class Main {
    public static void main(String[] args) {
        Person person = new Person("Sandi aji pamungkas", "solo");
        System.out.println(person.getName());
        System.out.println(person.getAddress());
        person.setAddress("jln evendi");
        System.out.println(person.getAddress());

        // Create a Student
        Student student = new Student("Pelajar", "Sleman", "oop", 1, 200.000);
        System.out.println(student.getProgram());
        System.out.println(student.getYear());
        System.out.println(student.getfee());
        student.setFee(200.000);
        System.out.println(student.getfee());

        // Create a Staff
        Staff staff = new Staff("Kaka", "gunung kidul", "SMA 1", 2500.000);
        System.out.println(staff.getName());
        System.out.println(staff.getAddress());
        System.out.println(staff.getSchool());
        System.out.println(staff.getPay());
        staff.setPay(5000000);
        System.out.println(staff.getPay());
    }
}