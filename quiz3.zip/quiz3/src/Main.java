public class Main {
    public static void main(String[] args) {
        Shape b1 = new Shape("Red", true);
        b1.setColor("Yellow");
        System.out.println(b1.getColor());
        b1.setFilled(false);
        System.out.println(b1.isFilled());
        System.out.println(b1);
    }
}