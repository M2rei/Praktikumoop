public class Main {
    public static void main(String[] args) {
        Circle c1 = new Circle(7, "red" );
        c1.setColor("red");
        System.out.println("Circle:");
        System.out.println("Radius: " + c1.getRadius());
        System.out.println("Color: " + c1.getColor());
        System.out.println("Area: " + c1.getArea());
        System.out.println("Info: " + c1.toString());

        Cylinder cy = new Cylinder(7, "red", 1.0 );
        System.out.println("Cylinder:");
        System.out.println("Radius: " + cy.getHeight());
        cy.setHeight();
        System.out.println("Area: " + cy.getVolume());
        System.out.println("Info: " + cy.toString());
    }
}